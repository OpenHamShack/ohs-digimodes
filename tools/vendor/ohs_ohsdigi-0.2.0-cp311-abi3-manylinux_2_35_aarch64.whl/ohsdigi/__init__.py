from .ohsdigi import *

__doc__ = ohsdigi.__doc__
if hasattr(ohsdigi, "__all__"):
    __all__ = ohsdigi.__all__